package rpgboss.player.entity

case class TestEntity(val x: Float, val y: Float, val speed: Float)
  extends EntityLike